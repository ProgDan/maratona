#!/usr/bin/python

import sys
import random

N = int(sys.argv[1])

print random.randint(1, N)
